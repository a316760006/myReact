import React from "react";

const MyContext = React.createContext();

export default MyContext;